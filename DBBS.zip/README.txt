Steps to Follow
1) Unzip all the contents of this .zip in a folder.
2) Now run the DBBS.bat to run the simulator.
3) Now, Upload the Result.txt on the website to get the final Output.

Thanks,
Team AsyncTech